class RoomMessagesController <ApplicationController

    @rooms = Room.all
    protect_from_forgery with: :null_session
    before_action :load_entities

    def index
        # Implement logic to fetch and display room messages here
        @room_messages = RoomMessage.all  # Example: Fetch all messages
      end
 def create
        @room_message = RoomMessage.create user: current_user,
        room: @room,
        message: params.dig(:room_message, :message)
        if @room_message.save
            # Success logic
          else
            end
end

   

protected

def load_entities
@room = params.dig(:room_message, :room_id)

end         
end

        