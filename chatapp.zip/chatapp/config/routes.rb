Rails.application.routes.draw do
   # devise_for :users
   resources :room_messages  # This would define routes for index, show, create, etc.
  
    root controller: :rooms, action: :index
  
    resources :room_messages
    resources :rooms
  end
  